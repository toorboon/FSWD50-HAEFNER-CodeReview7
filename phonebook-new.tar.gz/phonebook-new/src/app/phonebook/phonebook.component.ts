import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phonebook',
  templateUrl: './phonebook.component.html',
  styleUrls: ['./phonebook.component.sass']
})
export class PhonebookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  

}
